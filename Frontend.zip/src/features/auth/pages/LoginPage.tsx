// Placeholder for future implementation.
export default function LoginPage() { return null; }
