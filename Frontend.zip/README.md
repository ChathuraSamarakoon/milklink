# MilkLink Frontend

React + TypeScript + Vite scaffold matching the supplied project structure.

## Run

```sh
npm install
npm run dev
```

## Verify

```sh
npm run build
npm run lint
```

All 46 page files are blank component placeholders. Shared modules and test files are placeholders. The app intentionally renders a blank screen ready for page design. Routing, providers, authentication, APIs, offline sync, PWA functionality and tests are not implemented. The manifest and logo file are reserved for future implementation.
